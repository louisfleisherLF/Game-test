/* Reads button bytes from argv[1], runs the game, writes every frame's framebuffer to argv[2]. */
#include <stdio.h>
#include <stdlib.h>
#include "app.h"
#include "gfx.h"
int main(int argc, char **argv) {
    if (argc < 3) return 2;
    FILE *in = fopen(argv[1], "rb"), *out = fopen(argv[2], "wb");
    if (!in || !out) return 2;
    app_init(12345);
#ifdef HAS_HIGHSCORE
    app_set_highscore(0, NULL);
#elif defined(HAS_SCOREBOARD)
    app_set_scoreboard(NULL, NULL);
#else
    app_set_save(NULL, NULL);
#endif
    app_set_button_names("Z", "X");
    int b;
    while ((b = fgetc(in)) != EOF) {
        app_tick((uint8_t)b);
        app_draw();
        fwrite(gfx_fb, 1, sizeof gfx_fb, out);
    }
    fclose(in); fclose(out);
    return 0;
}
