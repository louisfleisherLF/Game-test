// Plays match3 in JS by finding valid swaps, records the button stream to in_match3.bin
const fs = require('fs'), vm = require('vm'), path = require('path');
for (const f of ['gfx.js', 'common.js', 'match3.js']) vm.runInThisContext(fs.readFileSync(path.join(__dirname, '..', f), 'utf8'), { filename: f });
const G = GAMES.match3, BTN = globalThis.BTN;
G.init(12345); G.setSave(null, null); G.setButtonNames('Z', 'X');
const out = [];
const step = (m) => { out.push(m); G.tick(m); };
const press = (m) => { step(m); step(0); };
function findSwap(cell) {
  const at = (r, c) => cell[r][c];
  const ok = (r, c) => { const k = at(r, c); let n = 1;
    for (let i = c - 1; i >= 0 && at(r, i) === k; i--) n++; for (let i = c + 1; i < 8 && at(r, i) === k; i++) n++; if (n >= 3) return true;
    n = 1; for (let i = r - 1; i >= 0 && at(i, c) === k; i--) n++; for (let i = r + 1; i < 8 && at(i, c) === k; i++) n++; return n >= 3; };
  const sw = (r1, c1, r2, c2) => { const t = cell[r1][c1]; cell[r1][c1] = cell[r2][c2]; cell[r2][c2] = t; };
  for (let r = 0; r < 8; r++) for (let c = 0; c < 8; c++) for (const [dr, dc] of [[0, 1], [1, 0]]) {
    const r2 = r + dr, c2 = c + dc; if (r2 >= 8 || c2 >= 8) continue;
    sw(r, c, r2, c2); const good = ok(r, c) || ok(r2, c2); sw(r, c, r2, c2);
    if (good) return [r, c, r2, c2];
  }
  return null;
}
for (let game = 0; game < 3; game++) {
  for (let mv = 0; mv < 40; mv++) {
    let d = G._debug();
    while (d.st !== 0 && d.st !== 4) { step(0); d = G._debug(); }
    if (d.st === 4 || d.moves === 0) break;
    const s = findSwap(d.cell.map((r) => Uint8Array.from(r)));
    if (!s) break;
    const goTo = (r, c) => { let [cr, cc] = G._debug().cur;
      while (cr !== r) { press(cr < r ? BTN.DOWN : BTN.UP); cr = G._debug().cur[0]; }
      while (cc !== c) { press(cc < c ? BTN.RIGHT : BTN.LEFT); cc = G._debug().cur[1]; } };
    goTo(s[0], s[1]); press(BTN.A); goTo(s[2], s[3]); press(BTN.A);
    if (mv % 7 === 3) { press(BTN.A); press(BTN.B); }   // some picks/cancels for coverage
    if (mv % 11 === 5) { press(BTN.A); press(BTN.RIGHT); press(BTN.RIGHT); press(BTN.A); } // likely bad swap
  }
  for (let i = 0; i < 60; i++) step(0);
  press(BTN.A); // restart from game over
}
fs.writeFileSync('in_match3.bin', Buffer.from(out));
console.log('recorded', out.length, 'ticks; final', JSON.stringify({ moves: G._debug().moves, st: G._debug().st }));
