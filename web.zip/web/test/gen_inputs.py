import random, sys
def rnd_stream(seed, n, allow=0x3F):
    r = random.Random(seed); out = []
    while len(out) < n:
        mask = r.randrange(64) & allow if r.random() < 0.8 else 0
        out += [mask] * r.randint(1, 14)
    return bytes(out[:n])

# match3 / 2048: pure random. tetris: random but fewer hard drops so games last a bit.
open('in_match3.bin','wb').write(rnd_stream(1, 6000))
open('in_g2048.bin','wb').write(rnd_stream(2, 6000))
t = bytearray(rnd_stream(3, 9000))
r = random.Random(33)
for i in range(len(t)):
    if t[i] & 0x20 and r.random() < 0.85: t[i] &= ~0x20
open('in_tetris.bin','wb').write(bytes(t))

# wordle: scripted typing that mirrors the on-screen keyboard cursor exactly
import re
_src = open('../../wordle/game/words.c').read()
common = re.findall(r'"([a-z]{5})"', re.search(r'WORDS_ANSWERS\[[^\]]*\] = \{(.*?)\};', _src, re.S).group(1))
def xs(x):
    x ^= (x << 13) & 0xFFFFFFFF; x ^= x >> 17; x ^= (x << 5) & 0xFFFFFFFF; return x & 0xFFFFFFFF
first = common[xs(12345) % len(common)]          # the first answer for seed 12345 -> one guaranteed win
ROWS = ['QWERTYUIOP', 'ASDFGHJKL', 'ZXCVBNM']
UP, DOWN, LEFT, RIGHT, A, B = 1, 2, 4, 8, 16, 32
out = bytearray(); kr = kc = 0
def press(m): out.extend([m, 0])
def goto(ch):
    global kr, kc
    tr = next(i for i, row in enumerate(ROWS) if ch in row); tc = ROWS[tr].index(ch)
    while kr != tr:
        press(DOWN); kr = (kr + 1) % 3; kc = min(kc, len(ROWS[kr]) - 1)
    while kc != tc:
        press(RIGHT); kc = (kc + 1) % len(ROWS[kr])
def type_word(w, enter=True):
    for ch in w.upper(): goto(ch); press(A)
    if enter: press(A); out.extend([0] * 45)
rr = random.Random(7)
for game in range(10):
    type_word('QQ', enter=False); press(A); out.extend([0] * 10)   # TOO SHORT
    press(B); press(B)
    type_word('QQQQQ'); out.extend([0] * 10)                         # NOT IN LIST
    for _ in range(5): press(B)
    words = [rr.choice(common) for _ in range(6)]
    if game == 0: words[2] = first
    for w in words:
        type_word(w)
        if game == 0 and w == first: break
    out.extend([0] * 20)
    press(A); out.extend([0] * 5); kr = kc = 0
open('in_wordle.bin', 'wb').write(bytes(out))
