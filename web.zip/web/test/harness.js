// node harness.js <game> <inputs.bin> <out.bin>
const fs = require('fs'), vm = require('vm'), path = require('path');
const web = path.join(__dirname, '..');
for (const f of ['gfx.js', 'common.js', 'words.js', 'match3.js', 'tetris.js', 'g2048.js', 'wordle.js'])
  vm.runInThisContext(fs.readFileSync(path.join(web, f), 'utf8'), { filename: f });
const [game, inPath, outPath] = process.argv.slice(2);
const G = globalThis.GAMES[game];
G.init(12345); G.setSave(null, null); G.setButtonNames('Z', 'X');
const inputs = fs.readFileSync(inPath);
const out = Buffer.alloc(inputs.length * 160 * 128 * 2);
const fbBytes = Buffer.from(globalThis.GFX.fb.buffer);
for (let i = 0; i < inputs.length; i++) {
  G.tick(inputs[i]); G.draw();
  fbBytes.copy(out, i * 40960);
}
fs.writeFileSync(outPath, out);
