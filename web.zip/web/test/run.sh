#!/bin/sh
# Differential test: C vs JS, byte-identical framebuffers for identical inputs.
# Expects the four C projects as siblings of the web/ folder.
set -e
cd "$(dirname "$0")"
R=../..
python3 gen_inputs.py >/dev/null
node record_match3.js >/dev/null
build() { gcc -std=c11 -O2 $4 -I$R/$2/game -o h_$1 harness.c $R/$2/game/gfx.c $R/$2/game/$3.c $R/$2/game/app.c $5; }
build match3 match3 match3 -DHAS_HIGHSCORE ""
build tetris tetris tetris -DHAS_SCOREBOARD ""
build g2048  g2048  g2048  "" ""
build wordle wordle wordle "" "$R/wordle/game/words.c"
for g in match3 tetris g2048 wordle; do
  ./h_$g in_$g.bin c_$g.bin
  node harness.js $g in_$g.bin js_$g.bin
  if cmp -s c_$g.bin js_$g.bin; then echo "$g: $(( $(stat -c%s c_$g.bin 2>/dev/null || stat -f%z c_$g.bin) / 40960 )) frames identical"; else echo "$g: DIFFERS"; exit 1; fi
done
rm -f h_* c_*.bin js_*.bin
